
/**
 * Write a description of class Desktop here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Desktop
{
    private String brand;
    private Tower typeOfTower; //minitower or full tower
    private Processor typeOfProcessor; //Intel or AMD
    private HardDrive typeOfHardDrive; //4TB, 8TB, or 16TB
    private Monitor typeOfMonitor; //24 inch, 27 inch, 32 inch
    private double totalCost = 0.0;
    public Desktop(String brand, Tower typeOfTower, Processor typeOfProcessor, HardDrive typeOfHardDrive, Monitor typeOfMonitor)
    {
        this.brand = brand;
        this.typeOfTower = typeOfTower;
        this.typeOfProcessor = typeOfProcessor;
        this.typeOfHardDrive = typeOfHardDrive;
        this.typeOfMonitor = typeOfMonitor;
    }
    public String getBrand()
    {
        return brand;
    }
    public Tower getTypeOfTower()
    {
        return typeOfTower;
    }
    public Processor getTypeOfProcessor()
    {
        return typeOfProcessor;
    }
    public HardDrive getTypeOfHardDrive()  
    {
        return typeOfHardDrive;
    }
    public Monitor getTypeOfMonitor()
    {
        return typeOfMonitor;
    }
    public void computeTotalCost()
    {
        totalCost = typeOfTower.getCostOfPart() + typeOfProcessor.getCostOfPart() + typeOfHardDrive.getCostOfPart() + typeOfMonitor.getCostOfPart();
    }
    public double getTotalCost()
    {
        computeTotalCost();
        return totalCost;
    }
    /*
     * (User Name)
	Desktop
	________________________________________________________________________
	Desktop Brand:                                                                           ASUS (or others available)
        Tower Size:                                                                                 Full Tower (or mini tower)
		Price:                                                                                         (price of tower)
	CPU Type:                                                                                  Intel (or AMD)
	CPU Speed:                                                                                Core i5-12600K (or others)
		Price:                                                                                           (price of CPU)
	Hard Drive Capacity:                                                                  Seagate 4TB 5900(or other
		Price:                                                                                          (price of hard drive)
	Monitor Size:                                                                            ASUS TUF Gaming 24 inch
		Price:                                                                                              (price of monitor)
	________________________________________________________________________
	Total:                                                                                      (total price of all components)
    */
    public String toString()
    {
        return "Desktop\n" + 
               "==================================================================================\n" + 
               "\tDesktop Brand:\t\t\t\t\t" + getBrand() + "\n" +
               "\tTower Size:\t\t\t\t\t" + getTypeOfTower().getBrand() + "\n" +
               "\t\tPrice:\t\t\t\t\t" + "$" + String.format("%.2f", getTypeOfTower().getCostOfPart()) + "\n" +
               "\tCPU Type:\t\t\t\t\t" + getTypeOfProcessor().getType() + "\n" +
               "\tCPU Speed:\t\t\t\t\t" + getTypeOfProcessor().getBrand() + "\n" +
               "\t\tPrice:\t\t\t\t\t" + "$" + String.format("%.2f", getTypeOfProcessor().getCostOfPart()) + "\n" +
               "\tHard Drive Capacity:\t\t\t\t" + getTypeOfHardDrive().getType() + " " + getTypeOfHardDrive().getCapacity() + "TB " + getTypeOfHardDrive().getRPM() + "\n" +
               "\t\tPrice:\t\t\t\t\t" + "$" + String.format("%.2f", getTypeOfHardDrive().getCostOfPart()) + "\n" +
               "\tMonitor Size:\t\t\t\t\t" + getTypeOfMonitor().getBrand() + " " + getTypeOfMonitor().getType() + " " + getTypeOfMonitor().getSize() + " inch" + "\n" +
               "\t\tPrice:\t\t\t\t\t" + "$" + String.format("%.2f", getTypeOfMonitor().getCostOfPart()) + "\n" +
               "==================================================================================\n" +
               "\tTotal:\t\t\t\t\t\t" + "$" + String.format("%.2f", getTotalCost());
    }
}
