
/**
 * Write a description of class Display here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Display
{
    private double size;
    private double costOfPart;
    public Display(double size, double costOfPart)
    {
        this.size = size;
        this.costOfPart = costOfPart;
    }
    public double getSize()
    {
        return size;
    }
    public double getCostOfPart()
    {
        return costOfPart;
    }
    // Option A: 15.6 inches for $100
    public String toString()
    {
        return getSize() + " inches for " + "$" + String.format("%.2f", getCostOfPart());
    }
}
