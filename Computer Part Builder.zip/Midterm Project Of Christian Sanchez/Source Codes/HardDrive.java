
/**
 * Write a description of class HardDrive here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class HardDrive
{
    private String type;
    private int capacity;
    private int rpm;
    private double costOfPart;
    public HardDrive(String type, int capacity, int rpm, double costOfPart)
    {
        this.type = type;
        this.capacity = capacity;
        this.rpm = rpm;
        this.costOfPart = costOfPart;
    }
    public String getType()
    {
        return type;
    }
    public int getCapacity()
    {
        return capacity;
    }
    public int getRPM()
    {
        return rpm;
    }
    public double getCostOfPart()
    {
        return costOfPart;
    }
    // Option A: Seagate 4TB 5900 hard drive for $79.99
    public String toString()
    {
        return getType() + " " + getCapacity() + "TB " + getRPM() + " hard drive for " + "$" + String.format("%.2f", getCostOfPart());
    }
}
