
/**
 * Write a description of class Laptop here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Laptop
{
    private String brand;
    private Processor typeOfProcessor;
    private HardDrive typeOfHardDrive;
    private Display typeOfDisplay;
    private double totalCost = 0.0;
    public Laptop(String brand, Processor typeOfProcessor, HardDrive typeOfHardDrive, Display typeOfDisplay)
    {
        this.brand = brand;
        this.typeOfProcessor = typeOfProcessor;
        this.typeOfHardDrive = typeOfHardDrive;
        this.typeOfDisplay = typeOfDisplay;
    }
    public String getBrand()
    {
        return brand;
    }
    public Processor getTypeOfProcessor()
    {
        return typeOfProcessor;
    }
    public HardDrive getTypeOfHardDrive()  
    {
        return typeOfHardDrive;
    }
    public Display getTypeOfDisplay()
    {
        return typeOfDisplay;
    }
    public void computeTotalCost()
    {
        totalCost = typeOfProcessor.getCostOfPart() + typeOfHardDrive.getCostOfPart() + typeOfDisplay.getCostOfPart();
    }
    public double getTotalCost()
    {
        computeTotalCost();
        return totalCost;
    }
    /*
     * (User Name)
	Laptop
	________________________________________________________________________
	Laptop Brand:                                  Asus (or others available) 
	CPU Type:                                                  Intel (or AMD)
	CPU Speed:                                     Core i5-12600K (or others)
		Price:                                             (price of CPU) 
	Hard Drive Capacity:                           Seagate 2TB 5400(or others
		Price:                                      (price of hard drive)
	Display Size:                                                 15.6 inches
		Price:                                         (price of monitor)
	________________________________________________________________________
	Total:                                    (total price of all components)                                          
    */
    public String toString()
    {
        return "Laptop\n" + 
               "========================================================================\n" + 
               "\tLaptop Brand:\t\t\t\t\t" + getBrand() + "\n" +
               "\tCPU Type:\t\t\t\t\t" + getTypeOfProcessor().getType() + "\n" +
               "\tCPU Speed:\t\t\t\t\t" + getTypeOfProcessor().getBrand() + "\n" +
               "\t\tPrice:\t\t\t\t\t" + "$" + String.format("%.2f", getTypeOfProcessor().getCostOfPart()) + "\n" +
               "\tHard Drive Capacity:\t\t\t\t" + getTypeOfHardDrive().getType() + " " + getTypeOfHardDrive().getCapacity() + "TB " + getTypeOfHardDrive().getRPM() + "\n" +
               "\t\tPrice:\t\t\t\t\t" + "$" + String.format("%.2f", getTypeOfHardDrive().getCostOfPart()) + "\n" +
               "\tDisplay Size:\t\t\t\t\t" + getTypeOfDisplay().getSize() + " inches" + "\n" +
               "\t\tPrice:\t\t\t\t\t" + "$" + String.format("%.2f", getTypeOfDisplay().getCostOfPart()) + "\n" +
               "========================================================================\n" +
               "\tTotal:\t\t\t\t\t\t" + "$" + String.format("%.2f", getTotalCost());
    }
}
