
/**
 * Write a description of class Monitor here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Monitor
{
    private String brand;
    private String type;
    private int size;
    private double costOfPart;
    public Monitor(String brand, String type, int size, double costOfPart)
    {
        this.brand = brand;
        this.type = type;
        this.size = size;
        this.costOfPart = costOfPart;
    }
    public String getBrand()
    {
        return brand;
    }
    public String getType()
    {
        return type;
    }
    public int getSize()
    {
        return size;
    }
    public double getCostOfPart()
    {
        return costOfPart;
    }
    // Option A: ASUS TUF Gaming 24 inch for $189.99
    public String toString()
    {
        return getBrand() + " " + getType() + " " + getSize() + " inch for " + "$" + String.format("%.2f", getCostOfPart());
    }
}
