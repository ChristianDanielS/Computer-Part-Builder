
/**
 * Write a description of class MyDeskClass here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class MyDeskClass
{
    static Scanner sc = new Scanner(System.in);
    static String name;
    public static void main(String[] args)
    {
        char answer = 'n';
        do
        {
            startApp();
            System.out.println("Would you like to run the program again (y/n)?: ");
            answer = sc.nextLine().charAt(0);
        }
        while(answer == 'y' || answer == 'Y');
        System.out.println("Thank you for using this program. Good bye.");
    }
    public static void startApp()
    {
        System.out.println("Do you want to build a desktop or laptop (y/n): ");
        char answer = sc.nextLine().charAt(0);
        if(answer == 'y' || answer == 'Y')
        {
            System.out.println("Please enter your name: ");
            name = sc.nextLine();
            System.out.println("Hi " + name + ", which type of computer would you like to build (desktop or laptop)?: ");
            String type = sc.nextLine();
            if(type.trim().equalsIgnoreCase("Desktop"))
                buildDesktop();
            else if(type.trim().equalsIgnoreCase("Laptop"))
                buildLaptop();
            else{
                System.out.println("Please enter desktop or laptop only. Thank you.");
            }
        }
    }
    public static void buildDesktop()
    {
        System.out.println("The desktop brands available are:\nAsus\nDell\nHP");
        System.out.print("Please choose a desktop brand (Asus, Dell, or HP): ");
        String brand = sc.nextLine();
        System.out.println("The sizes of the towers available are:\nOption A: Mini Tower\nOption B: Full Tower");
        System.out.print("Please choose a tower size (option A or B): ");
        char choiceOfTower = sc.nextLine().charAt(0);
        Tower tower = null;
        // mini tower
        if(choiceOfTower == 'a' || choiceOfTower == 'A')
        {
            System.out.println("The mini towers available are:\nOption A: Cougar QBX Ultra Compact Pro Gaming Case for $62.99\nOption B: Cougar Dust 2 Computer Case for $155.99");
            System.out.print("Please choose a mini tower (option A or B): ");
            char typeOfMiniTower = sc.nextLine().charAt(0);
            if(typeOfMiniTower == 'a' || typeOfMiniTower == 'A')
            {
                tower = new Tower("Cougar", "QBX Ultra Compact Pro Gaming Case", 62.99);
            }
            else if(typeOfMiniTower == 'b' || typeOfMiniTower == 'B')
            {
                tower = new Tower("Cougar", "Dust 2 Computer Case", 155.99);
            }
        }
        // full tower
        else if(choiceOfTower == 'b' || choiceOfTower == 'B')
        {
            System.out.println("The full towers available are:\nOption A: Corsair CC-9011219 for $229.99\nOption B: Phanteks Enthoo Pro 2 for $189.99");
            System.out.print("Please choose a full tower (option A or B): ");
            char typeOfFullTower = sc.nextLine().charAt(0);
            if(typeOfFullTower == 'a' || typeOfFullTower == 'A')
            {
                tower = new Tower("Corsair", "CC-9011219", 229.99);
            }
            else if(typeOfFullTower == 'b' || typeOfFullTower == 'B')
            {
                tower = new Tower("Phanteks", "Enthoo Pro 2", 189.99);
            }
        }
        System.out.println(tower.toString());
        //Processors
        System.out.println("The CPU brands available are:\nAMD\nIntel");
        System.out.print("Please choose a CPU brand (AMD or Intel): ");
        String processorBrand = sc.nextLine();
        Processor processor = null;
        if(processorBrand.trim().equalsIgnoreCase("AMD"))
        {
            System.out.println("The available AMD CPU speeds are:\nOption A: AMD Ryzen 9 5900x for $489.99\nOption B: AMD Ryzen 7 5800x for $349.99\nOption C: AMD Ryzen 5 5600x for $228.98");
            System.out.print("Please choose an AMD CPU (option A, B, or C): ");
            char typeOfAMDProcessor = sc.nextLine().charAt(0);
            if(typeOfAMDProcessor == 'a' || typeOfAMDProcessor == 'A')
            {
                processor = new Processor("AMD", "Ryzen 9 5900x", 489.99);
            }
            else if(typeOfAMDProcessor == 'b' || typeOfAMDProcessor == 'B')
            {
                processor = new Processor("AMD", "Ryzen 7 5800x", 349.99);
            }
            else if(typeOfAMDProcessor == 'c' || typeOfAMDProcessor == 'C')
            {
                processor = new Processor("AMD", "Ryzen 5 5600x", 228.98);
            }
        }
        else if (processorBrand.trim().equalsIgnoreCase("Intel"))
        {
            System.out.println("The available Intel CPU speeds are:\nOption A: Intel Core i5-12600K for $278.98\nOption B: Intel Core i7-12700K for $384.98\nOption C: Intel Core i9-12900K for $610.99");
            System.out.print("Please choose an Intel CPU (option A, B, or C): ");
            char typeOfIntelProcessor = sc.nextLine().charAt(0);
            if(typeOfIntelProcessor == 'a' || typeOfIntelProcessor == 'A')
            {
                processor = new Processor("Intel", "Core i5-12600K", 278.98);
            }
            else if(typeOfIntelProcessor == 'b' || typeOfIntelProcessor == 'B')
            {
                processor = new Processor("Intel", "Core i7-12700K", 384.98);
            }
            else if(typeOfIntelProcessor == 'c' || typeOfIntelProcessor == 'C')
            {
                processor = new Processor("Intel", "Core i9-12900K", 610.99);
            }
        }    
        System.out.println(processor.toString());
        //Hard Drives
        HardDrive hardDrive = null;
        System.out.println("The available hard drive capacities are:\nOption A: Seagate 4TB 5900 hard drive for $79.99\nOption B: Seagate 8TB 7200 hard drive for $179.99\nOption C: Seagate 18TB 7200 hard drive for $399.99");
        System.out.print("Please chose a hard drive (option A, B, or C): ");
        char typeOfHardDrive = sc.nextLine().charAt(0);
        if(typeOfHardDrive == 'a' || typeOfHardDrive == 'A')
        {
            hardDrive = new HardDrive("Seagate", 4, 5900, 79.99);
        }
        else if(typeOfHardDrive == 'b' || typeOfHardDrive == 'B')
        {
            hardDrive = new HardDrive("Seagate", 8, 7200, 179.99);
        }
        else if(typeOfHardDrive == 'c' || typeOfHardDrive == 'C')
        {
            hardDrive = new HardDrive("Seagate", 18, 7200, 399.99);
        }
        System.out.println(hardDrive.toString());
        //Monitors
        Monitor monitor = null;
        System.out.println("The available monitors are:\nOption A: ASUS TUF Gaming 24 inch for $189.99\nOption B: Samsung Odyssey 27 inch for $599.99\nOption C: GIGABYTE M32U 32 inch for $739.99");
        System.out.print("Please choose a monitor (option A, B, or C): ");
        char typeOfMonitor = sc.nextLine().charAt(0);
        if(typeOfMonitor == 'a' || typeOfMonitor == 'A')
        {
            monitor = new Monitor("Asus", "TUF Gaming", 24, 189.99);
        }
        else if(typeOfMonitor == 'b' || typeOfMonitor == 'B')
        {
            monitor = new Monitor("Samsung", "Odysssey", 27, 599.99);
        }
        else if(typeOfMonitor == 'c' || typeOfMonitor == 'C')
        {
            monitor = new Monitor("GIGABYTE", "M32U", 32, 739.99);
        }
        System.out.println(monitor.toString());
        System.out.println(name + ":");
        Desktop desktop = new Desktop(brand, tower, processor, hardDrive, monitor);
        System.out.println(desktop.toString());
    }
    public static void buildLaptop()
    {
        System.out.println("The laptop brands available are:\nAsus\nDell\nHP");
        System.out.print("Please choose a desktop brand (Asus, Dell, or HP): ");
        String brand = sc.nextLine();
        /*
        System.out.println("The sizes of the towers available are:\nOption A: Mini Tower\nOption B: Full Tower");
        System.out.print("Please choose a tower size (option A or B): ");
        char choiceOfTower = sc.nextLine().charAt(0);
        Tower tower = null;
        // mini tower
        if(choiceOfTower == 'a' || choiceOfTower == 'A')
        {
            System.out.println("The mini towers available are:\nOption A: Cougar QBX Ultra Compact Pro Gaming Case for $62.99\nOption B: Cougar Dust 2 Computer Case for $155.99");
            System.out.print("Please choose a mini tower (option A or B): ");
            char typeOfMiniTower = sc.nextLine().charAt(0);
            if(typeOfMiniTower == 'a' || typeOfMiniTower == 'A')
            {
                tower = new Tower("Cougar", "QBX Ultra Compact Pro Gaming Case", 62.99);
            }
            else if(typeOfMiniTower == 'b' || typeOfMiniTower == 'B')
            {
                tower = new Tower("Cougar", "Dust 2 Computer Case", 155.99);
            }
        }
        // full tower
        else if(choiceOfTower == 'b' || choiceOfTower == 'B')
        {
            System.out.println("The full towers available are:\nOption A: Corsair CC-9011219 for $229.99\nOption B: Phanteks Enthoo Pro 2 for $189.99");
            System.out.print("Please choose a full tower (option A or B): ");
            char typeOfFullTower = sc.nextLine().charAt(0);
            if(typeOfFullTower == 'a' || typeOfFullTower == 'A')
            {
                tower = new Tower("Corsair", "CC-9011219", 229.99);
            }
            else if(typeOfFullTower == 'b' || typeOfFullTower == 'B')
            {
                tower = new Tower("Phanteks", "Enthoo Pro 2", 189.99);
            }
        }
        System.out.println(tower.toString());
        */
        //Processors
        System.out.println("The CPU brands available are:\nAMD\nIntel");
        System.out.print("Please choose a CPU brand (AMD or Intel): ");
        String processorBrand = sc.nextLine();
        Processor processor = null;
        if(processorBrand.trim().equalsIgnoreCase("AMD"))
        {
            System.out.println("The available AMD CPU speeds are:\nOption A: AMD Ryzen 9 5900x for $489.99\nOption B: AMD Ryzen 7 5800x for $349.99\nOption C: AMD Ryzen 5 5600x for $228.98");
            System.out.print("Please chose an AMD CPU (option A, B, or C): ");
            char typeOfAMDProcessor = sc.nextLine().charAt(0);
            if(typeOfAMDProcessor == 'a' || typeOfAMDProcessor == 'A')
            {
                processor = new Processor("AMD", "Ryzen 9 5900x", 489.99);
            }
            else if(typeOfAMDProcessor == 'b' || typeOfAMDProcessor == 'B')
            {
                processor = new Processor("AMD", "Ryzen 7 5800x", 349.99);
            }
            else if(typeOfAMDProcessor == 'c' || typeOfAMDProcessor == 'C')
            {
                processor = new Processor("AMD", "Ryzen 5 5600x", 228.98);
            }
        }
        else if (processorBrand.trim().equalsIgnoreCase("Intel"))
        {
            System.out.println("The available Intel CPU speeds are:\nOption A: Intel Core i5-12600K for $278.98\nOption B: Intel Core i7-12700K for $384.98\nOption C: Intel Core i9-12900K for $610.99");
            System.out.print("Please chose an Intel CPU (option A, B, or C): ");
            char typeOfIntelProcessor = sc.nextLine().charAt(0);
            if(typeOfIntelProcessor == 'a' || typeOfIntelProcessor == 'A')
            {
                processor = new Processor("Intel", "Core i5-12600K", 278.98);
            }
            else if(typeOfIntelProcessor == 'b' || typeOfIntelProcessor == 'B')
            {
                processor = new Processor("Intel", "Core i7-12700K", 384.98);
            }
            else if(typeOfIntelProcessor == 'c' || typeOfIntelProcessor == 'C')
            {
                processor = new Processor("Intel", "Core i9-12900K", 610.99);
            }
        }    
        System.out.println(processor.toString());
        //Hard Drives
        HardDrive hardDrive = null;
        System.out.println("The available hard drive capacities are:\nOption A: Seagate 2TB 5400 for $68.96\nOption B: Seagate 5TB 5400 for $123.68\nOption C: Seagate 16TB 7200 for $349.99");
        System.out.print("Please chose a hard drive (option A, B, or C): ");
        char typeOfHardDrive = sc.nextLine().charAt(0);
        if(typeOfHardDrive == 'a' || typeOfHardDrive == 'A')
        {
            hardDrive = new HardDrive("Seagate", 2, 5400, 68.96);
        }
        else if(typeOfHardDrive == 'b' || typeOfHardDrive == 'B')
        {
            hardDrive = new HardDrive("Seagate", 5, 5400, 123.68);
        }
        else if(typeOfHardDrive == 'c' || typeOfHardDrive == 'C')
        {
            hardDrive = new HardDrive("Seagate", 16, 7200, 349.99);
        }
        System.out.println(hardDrive.toString());
        //Laptop Display 
        Display display = null;
        System.out.println("The available displays are:\nOption A: 15.6 inches for $100\nOption B: 14 inches for $70");
        System.out.print("Please choose a display (option A or B): ");
        char typeOfMonitor = sc.nextLine().charAt(0);
        if(typeOfMonitor == 'a' || typeOfMonitor == 'A')
        {
            //public Display(double size, double costOfPart)
            display = new Display(15.6, 100.00);
        }
        else if(typeOfMonitor == 'b' || typeOfMonitor == 'B')
        {
            display = new Display(14.0, 70.00);
        }
        System.out.println(display.toString());
        System.out.println(name + ":");
        //public Laptop(String brand, Processor typeOfProcessor, HardDrive typeOfHardDrive, Display typeOfDisplay)
        Laptop laptop = new Laptop(brand, processor, hardDrive, display);
        System.out.println(laptop.toString());
    }
}
