
/**
 * Write a description of class Processor here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Processor
{
    private String type;
    private String brand;
    private double costOfPart;
    public Processor(String type, String brand, double costOfPart)
    {
        this.type = type;
        this.brand = brand;
        this.costOfPart = costOfPart;
    }
    public String getType()
    {
        return type;
    }
    public String getBrand()
    {
        return brand;
    }
    public double getCostOfPart()
    {
        return costOfPart;
    }
    // Option A: AMD Ryzen 9 5900x for $489.99
    public String toString()
    {
        return getType() + " " + getBrand() + " for " + "$" + String.format("%.2f", getCostOfPart());
    }
}
