
/**
 * Write a description of class Tower here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tower
{
    private String type;
    private String brand;
    private double costOfPart;
    // tower = new Tower("Cougar", "QBX Ultra Compact Pro Gaming Case", 62.99);
    public Tower(String type, String brand, double costOfPart)
    {
        this.type = type;
        this.brand = brand;
        this.costOfPart = costOfPart;
    }
    public String getType()
    {
        return type;
    }
    public String getBrand()
    {
        return brand;
    }
    public double getCostOfPart()
    {
        return costOfPart;
    }
    // Option A: Cougar QBX Ultra Compact Pro Gaming Case for $62.99 
    public String toString()
    {
        return getType() + " " + getBrand() + " for " + "$" + String.format("%.2f", getCostOfPart());
    }
}
